//
//  StopSearchingException.java
//  ChessApp
//
//  Created by Peter Hunter on Mon Dec 31 2001.
//  Copyright (c) 2001 Peter Hunter. All rights reserved.
//

final class StopSearchingException extends Exception {

}
