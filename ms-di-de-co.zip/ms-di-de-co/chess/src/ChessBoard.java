// Decompiled by DJ v3.11.11.95 Copyright 2009 Atanas Neshkov  Date: 5/4/2011 11:59:59 PM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ChessBoard.java


import java.awt.*;
import java.awt.image.ImageProducer;
import java.beans.PropertyVetoException;
import java.net.URL;
import javax.swing.*;

import move.Move;

// Referenced classes of package org.op.chess:
//            Square, Move

public class ChessBoard extends JPanel
{
    final class BLabel extends JLabel
    {

        BLabel(String s)
        {
            super(s);
            setHorizontalAlignment(0);
            setVerticalAlignment(0);
        }
    }


    public ChessBoard()
    {
        first = true;
        pieceSize = 32;
        squareSize = 42;
        moving = false;
        move = null;
        loadImages();
        JPanel boardPanel = new JPanel();
        boardPanel.setLayout(new GridLayout(10, 10));
        letterRow(boardPanel);
        for(int i = 0; i < 8; i++)
        {
            boardPanel.add(new BLabel(convertNum(i, false)));
            for(int j = 0; j < 8; j++)
            {
                square[i][j] = new Square(i, j, this);
                boardPanel.add(square[i][j]);
            }

            boardPanel.add(new BLabel(convertNum(i, false)));
        }

        letterRow(boardPanel);
        setupBoard();
        mmPanel.setLayout(new GridLayout(2, 1));
        Icon whiteMoveIcon = new ImageIcon(getImage("wMove.gif"));
        wtm = new JLabel(whiteMoveIcon);
        Icon blackMoveIcon = new ImageIcon(getImage("bMove.gif"));
        btm = new JLabel(blackMoveIcon);
        wtm.setVerticalAlignment(3);
        wtm.setHorizontalAlignment(0);
        wtm.setPreferredSize(new Dimension(104, 168));
        btm.setVerticalAlignment(1);
        btm.setHorizontalAlignment(0);
        btm.setPreferredSize(new Dimension(104, 168));
        btm.setVisible(false);
        mmPanel.add(btm);
        mmPanel.add(wtm);
        setLayout(new FlowLayout());
        add(boardPanel);
        add(mmPanel);
    }

    public void setupBoard()
    {
        for(int i = 0; i < 8; i++)
        {
            for(int j = 0; j < 8; j++)
            {
                int c = START_COLOR[j + 8 * i];
                if(c != 6)
                {
                    int p = START_PIECE[j + 8 * i];
                    square[i][j].setIcon(pieceImage[c][p]);
                } else
                {
                    square[i][j].setIcon(null);
                }
            }

        }

        first = true;
    }

    public void makeMove()
    {
        makeMove(move);
    }

    public void makeMove(Move move)
    {
        int fromCol = move.getFromCol();
        int fromRow = move.getFromRow();
        square[move.getToRow()][move.getToCol()].setIcon(square[fromRow][fromCol].getIcon());
        square[fromRow][fromCol].setIcon(null);
    }

    public void makeMoveWithPromote(Move move, int promote, boolean whiteToMove)
    {
        square[move.getToRow()][move.getToCol()].setIcon(pieceImage[whiteToMove ? 0 : 1][promote]);
        square[move.getFromRow()][move.getFromCol()].setIcon(null);
    }

    public void clear(int row, int col)
    {
        square[row][col].setIcon(null);
    }

    public void switchMoveMarkers(boolean whiteToMove)
    {
        if(whiteToMove)
        {
            wtm.setVisible(true);
            btm.setVisible(false);
        } else
        {
            btm.setVisible(true);
            wtm.setVisible(false);
        }
    }

    public int promotionDialog(boolean whiteMoving)
    {
        int index = whiteMoving ? 0 : 1;
        Object options[] = {
            pieceImage[index][1], pieceImage[index][2], pieceImage[index][3], pieceImage[index][4]
        };
        int choice = JOptionPane.showOptionDialog(this, "Promote to which piece?", "Promotion", 1, 3, null, options, options[3]);
        if(choice == -1)
            choice = 3;
        return choice + 1;
    }

    public int getPieceSize()
    {
        return pieceSize;
    }

    public void setPieceSize(int size)
    {
        pieceSize = size;
    }

    public int getSquareSize()
    {
        return squareSize;
    }

    public void setSquareSize(int size)
    {
        squareSize = size;
    }

    public boolean isMoving()
    {
        return moving;
    }

    public void setMoving(boolean m)
    {
        moving = m;
    }

    public Move getMove()
    {
        return move;
    }

    void selected(int row, int col, boolean empty)
    {
        if(moving)
            return;
        if(first)
            if(empty)
            {
                return;
            } else
            {
                startCol = col;
                startRow = row;
                first = false;
                return;
            }
        int from = (startRow << 3) + startCol;
        int to = (row << 3) + col;
        Move newMove = new Move(from, to);
        moving = true;
        try
        {
            fireVetoableChange("move", null, newMove);
            move = newMove;
            firePropertyChange("move", null, move);
        }
        catch(PropertyVetoException pve)
        {
            moving = false;
        }
        first = true;
    }

    private void letterRow(JPanel p)
    {
        p.add(new JPanel());
        for(int i = 0; i < 8; i++)
            p.add(new BLabel(convertNum(i, true)));

        p.add(new JPanel());
    }

    private String convertNum(int temp, boolean first)
    {
        if(first)
            return (new Character((char)(97 + temp))).toString();
        else
            return Integer.toString(8 - temp);
    }

    private void loadImages()
    {
        for(int i = 0; i < 2; i++)
        {
            for(int j = 0; j < 6; j++)
                pieceImage[i][j] = new ImageIcon(getImage(imageFilename[i][j]));

        }

    }

    private Image getImage(String path)
    {
        Toolkit tool = Toolkit.getDefaultToolkit();
        URL imURL = getClass().getResource("images/" + path);
        if(imURL == null)
            throw new RuntimeException("Huh? No resource");
        ImageProducer ip = null;
        try
        {
            ip = (ImageProducer)imURL.getContent();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        return tool.createImage(ip);
    }

    private static final int EMPTY = 6;
    private static final int START_COLOR[] = {
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
        1, 1, 1, 1, 1, 1, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 0
    };
    private static final int START_PIECE[] = {
        3, 1, 2, 4, 5, 2, 1, 3, 0, 0, 
        0, 0, 0, 0, 0, 0, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
        6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 
        0, 0, 0, 0, 0, 0, 3, 1, 2, 4, 
        5, 2, 1, 3
    };
    private final Square square[][] = new Square[8][8];
    private boolean first;
    private final JLabel wtm;
    private final JLabel btm;
    private final JPanel mmPanel = new JPanel();
    private static Icon pieceImage[][] = new ImageIcon[2][6];
    private static final String imageFilename[][] = {
        {
            "wp.gif", "wn.gif", "wb.gif", "wr.gif", "wq.gif", "wk.gif"
        }, {
            "bp.gif", "bn.gif", "bb.gif", "br.gif", "bq.gif", "bk.gif"
        }
    };
    private int startCol;
    private int startRow;
    private int pieceSize;
    private int squareSize;
    private boolean moving;
    private Move move;

}
