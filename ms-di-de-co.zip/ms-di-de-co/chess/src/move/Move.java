// Decompiled by DJ v3.11.11.95 Copyright 2009 Atanas Neshkov  Date: 5/5/2011 12:04:57 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Move.java

package move;


public class Move
{

    public Move(int from, int to)
    {
        this.from = from;
        this.to = to;
    }

    public final int getFrom()
    {
        return from;
    }

    public final int getTo()
    {
        return to;
    }

    public final int getFromRow()
    {
        return from >> 3;
    }

    public final int getFromCol()
    {
        return from % 8;
    }

    public final int getToRow()
    {
        return to >> 3;
    }

    public final int getToCol()
    {
        return to % 8;
    }

    protected final int from;
    protected final int to;
}
