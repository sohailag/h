// Decompiled by DJ v3.11.11.95 Copyright 2009 Atanas Neshkov  Date: 5/5/2011 12:04:03 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ChessBoardBeanInfo.java


import java.beans.*;

public class ChessBoardBeanInfo extends SimpleBeanInfo
{

    public ChessBoardBeanInfo()
    {
    }

    private static BeanDescriptor getBdescriptor()
    {
        BeanDescriptor beanDescriptor = new BeanDescriptor(ChessBoard.class, null);
        return beanDescriptor;
    }

    private static PropertyDescriptor[] getPdescriptor()
    {
        PropertyDescriptor properties[] = new PropertyDescriptor[5];
        try
        {
            properties[0] = new PropertyDescriptor("squareSize", ChessBoard.class, "getSquareSize", "setSquareSize");
            properties[1] = new PropertyDescriptor("moving", ChessBoard.class, "isMoving", "setMoving");
            properties[2] = new PropertyDescriptor("pieceSize", ChessBoard.class, "getPieceSize", "setPieceSize");
            properties[3] = new PropertyDescriptor("move", ChessBoard.class, "getMove", null);
            properties[4] = new PropertyDescriptor("toolTipText", ChessBoard.class, "getToolTipText", "setToolTipText");
        }
        catch(IntrospectionException introspectionexception) { }
        return properties;
    }

    private static EventSetDescriptor[] getEdescriptor()
    {
        EventSetDescriptor eventSets[] = new EventSetDescriptor[12];
        try
        {
            eventSets[0] = new EventSetDescriptor(ChessBoard.class, "mouseMotionListener", java.awt.event.MouseMotionListener.class, new String[] {
                "mouseDragged", "mouseMoved"
            }, "addMouseMotionListener", "removeMouseMotionListener");
            eventSets[1] = new EventSetDescriptor(ChessBoard.class, "ancestorListener", javax.swing.event.AncestorListener.class, new String[] {
                "ancestorAdded", "ancestorMoved", "ancestorRemoved"
            }, "addAncestorListener", "removeAncestorListener");
            eventSets[2] = new EventSetDescriptor(ChessBoard.class, "inputMethodListener", java.awt.event.InputMethodListener.class, new String[] {
                "inputMethodTextChanged", "caretPositionChanged"
            }, "addInputMethodListener", "removeInputMethodListener");
            eventSets[3] = new EventSetDescriptor(ChessBoard.class, "componentListener", java.awt.event.ComponentListener.class, new String[] {
                "componentShown", "componentResized", "componentHidden", "componentMoved"
            }, "addComponentListener", "removeComponentListener");
            eventSets[4] = new EventSetDescriptor(ChessBoard.class, "hierarchyBoundsListener", java.awt.event.HierarchyBoundsListener.class, new String[] {
                "ancestorResized", "ancestorMoved"
            }, "addHierarchyBoundsListener", "removeHierarchyBoundsListener");
            eventSets[5] = new EventSetDescriptor(ChessBoard.class, "mouseListener", java.awt.event.MouseListener.class, new String[] {
                "mouseReleased", "mouseEntered", "mouseClicked", "mousePressed", "mouseExited"
            }, "addMouseListener", "removeMouseListener");
            eventSets[6] = new EventSetDescriptor(ChessBoard.class, "focusListener", java.awt.event.FocusListener.class, new String[] {
                "focusGained", "focusLost"
            }, "addFocusListener", "removeFocusListener");
            eventSets[7] = new EventSetDescriptor(ChessBoard.class, "propertyChangeListener", java.beans.PropertyChangeListener.class, new String[] {
                "propertyChange"
            }, "addPropertyChangeListener", "removePropertyChangeListener");
            eventSets[8] = new EventSetDescriptor(ChessBoard.class, "keyListener", java.awt.event.KeyListener.class, new String[] {
                "keyReleased", "keyPressed", "keyTyped"
            }, "addKeyListener", "removeKeyListener");
            eventSets[9] = new EventSetDescriptor(ChessBoard.class, "hierarchyListener", java.awt.event.HierarchyListener.class, new String[] {
                "hierarchyChanged"
            }, "addHierarchyListener", "removeHierarchyListener");
            eventSets[10] = new EventSetDescriptor(ChessBoard.class, "containerListener", java.awt.event.ContainerListener.class, new String[] {
                "componentRemoved", "componentAdded"
            }, "addContainerListener", "removeContainerListener");
            eventSets[11] = new EventSetDescriptor(ChessBoard.class, "vetoableChangeListener", java.beans.VetoableChangeListener.class, new String[] {
                "vetoableChange"
            }, "addVetoableChangeListener", "removeVetoableChangeListener");
        }
        catch(IntrospectionException introspectionexception) { }
        return eventSets;
    }

    private static MethodDescriptor[] getMdescriptor()
    {
        MethodDescriptor methods[] = new MethodDescriptor[1];
        try
        {
            methods[0] = new MethodDescriptor((ChessBoard.class).getMethod("setupBoard", new Class[0]));
            methods[0].setDisplayName("Set up the board");
        }
        catch(Exception exception) { }
        return methods;
    }

    public BeanDescriptor getBeanDescriptor()
    {
        return getBdescriptor();
    }

    public PropertyDescriptor[] getPropertyDescriptors()
    {
        return getPdescriptor();
    }

    public EventSetDescriptor[] getEventSetDescriptors()
    {
        return getEdescriptor();
    }

    public MethodDescriptor[] getMethodDescriptors()
    {
        return getMdescriptor();
    }

    public int getDefaultPropertyIndex()
    {
        return -1;
    }

    public int getDefaultEventIndex()
    {
        return -1;
    }

    private static final int PROPERTY_squareSize = 0;
    private static final int PROPERTY_moving = 1;
    private static final int PROPERTY_pieceSize = 2;
    private static final int PROPERTY_move = 3;
    private static final int PROPERTY_toolTipText = 4;
    private static final int EVENT_mouseMotionListener = 0;
    private static final int EVENT_ancestorListener = 1;
    private static final int EVENT_inputMethodListener = 2;
    private static final int EVENT_componentListener = 3;
    private static final int EVENT_hierarchyBoundsListener = 4;
    private static final int EVENT_mouseListener = 5;
    private static final int EVENT_focusListener = 6;
    private static final int EVENT_propertyChangeListener = 7;
    private static final int EVENT_keyListener = 8;
    private static final int EVENT_hierarchyListener = 9;
    private static final int EVENT_containerListener = 10;
    private static final int EVENT_vetoableChangeListener = 11;
    private static final int METHOD_setupBoard0 = 0;
    private static final int defaultPropertyIndex = -1;
    private static final int defaultEventIndex = -1;
}
