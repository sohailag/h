// Decompiled by DJ v3.11.11.95 Copyright 2009 Atanas Neshkov  Date: 5/5/2011 12:07:30 AM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Square.java



import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

// Referenced classes of package org.op.chess:
//            ChessBoard

final class Square extends JPanel
{
    class SquareMouseListener extends MouseAdapter
    {

        public void mouseEntered(MouseEvent e)
        {
            mouseIn = true;
            repaint();
        }

        public void mouseExited(MouseEvent e)
        {
            mouseIn = false;
            repaint();
        }

        public void mouseClicked(MouseEvent e)
        {
            board.selected(y, x, jl.getIcon() == null);
        }

        SquareMouseListener()
        {
        }
    }


    Square(int y, int x, ChessBoard b)
    {
        mouseIn = false;
        this.x = x;
        this.y = y;
        board = b;
        if((x + y) % 2 == 0)
            setBackground(Color.white);
        else
            setBackground(Color.gray);
        int square = board.getSquareSize();
        setPreferredSize(new Dimension(square, square));
        int piece = board.getPieceSize();
        jl.setPreferredSize(new Dimension(piece, piece));
        add(jl);
        addMouseListener(new SquareMouseListener());
    }

    void setIcon(Icon i)
    {
        jl.setIcon(i);
    }

    Icon getIcon()
    {
        return jl.getIcon();
    }

    public void paint(Graphics g)
    {
        super.paint(g);
        if(mouseIn)
        {
            g.setColor(Color.blue);
            g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
        }
    }

    private final int x;
    private final int y;
    private final ChessBoard board;
    private final JLabel jl = new JLabel();
    private boolean mouseIn;





}
