import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Chess extends Applet
    implements MouseListener, MouseMotionListener
{

    String path;
    String passwd;
    Image toolBar;
    AudioClip beep;
    Image wPawn;
    Image bPawn;
    Image wKnight;
    Image bKnight;
    Image wBishop;
    Image bBishop;
    Image wRook;
    Image bRook;
    Image wQueen;
    Image bQueen;
    Image wKing;
    Image bKing;
    EngineHandle engine;
    int offsetX;
    int offsetY;
    int barX;
    int barY;
    int spcX;
    int sqrWidth;
    int barWidth;
    int barHeight;
    int fromBoard;
    int toBoard;
    Color bckColor;
    Color whtColor;
    Color blkColor;
    Color whtHighLight;
    Color blkHighLight;
    boolean menuOff;
    boolean moveOff;
    boolean engineOff;
    boolean rotate;
    boolean blind;
    boolean monitor;
    int dragX;
    int dragY;
    boolean dragging;
    String cName[];
    String content[];
    boolean lightsBoard[];
    PopupMenu popupMenu;
    PopupMenu setupMenu;
    Menu depthMenu;
    Menu extendMenu;
    Menu timeMenu;
    Menu gameMenu;
    Menu mateMenu;
    Menu levelMenu;
    Menu boardMenu;
    Menu modeMenu;
    Menu fairyMenu;
    Dialog dialog;
    Checkbox knightBox;
    Checkbox bishopBox;
    Checkbox rookBox;
    Checkbox queenBox;
    char promotePiece;
    int serverPort;
    int remotePort;
    ChessServer server;
    ServerSocket rmtSocket;
    final int LIGHTS_OFF = 0;
    final int LIGHTS_ON = 1;
    final int LIGHTS_EQUAL = 2;

    public Chess()
    {
    }

    public void start()
    {
    }

    public void stop()
    {
    }

    public void destroy()
    {
    }

    public void mouseExited(MouseEvent mouseevent)
    {
    }

    public void mouseEntered(MouseEvent mouseevent)
    {
    }

    public void mouseClicked(MouseEvent mouseevent)
    {
    }

    public void mouseMoved(MouseEvent mouseevent)
    {
    }

    private void evaluatePARAM()
    {
        content = (new String[] {
            "", "", "", "", "", "", "", "", "", "", 
            "", "", "", "", "BEGIN", "BACK", "PLAY", "FORWARD", "END", "", 
            "", "", ""
        });
        cName = (new String[] {
            "WHTSQR", "IMGPATH", "BARX", "MOVE", "BLKSQR", "BGCOLOR", "BARY", "MENU", "ENGINE", "EXECUTE", 
            "PORT", "PASS", "REMOTE", "RMTPORT", "FKT1", "FKT2", "FKT3", "FKT4", "FKT5", "WHTLIGHT", 
            "BLKLIGHT", "ADDSPACE", "LANGUAGE"
        });
        for(int i = 0; i < cName.length; i++)
        {
            if(getParameter(cName[i]) != null)
            {
                content[i] = getParameter(cName[i]);
            }
        }

        if(content[0].length() > 0)
        {
            whtColor = Color.decode(content[0]);
        }
        if(content[4].length() > 0)
        {
            blkColor = Color.decode(content[4]);
        }
        if(content[5].length() > 0)
        {
            bckColor = Color.decode(content[5]);
        }
        if(content[19].length() > 0)
        {
            whtHighLight = Color.decode(content[19]);
        } else
        if(content[0].length() > 0)
        {
            whtHighLight = Color.decode(content[0]);
        }
        if(content[20].length() > 0)
        {
            blkHighLight = Color.decode(content[20]);
        } else
        if(content[4].length() > 0)
        {
            blkHighLight = Color.decode(content[4]);
        }
        if(content[2].length() > 0)
        {
            barX = Integer.parseInt(content[2]);
        }
        if(content[6].length() > 0)
        {
            barY = Integer.parseInt(content[6]);
        }
        if(content[21].length() > 0)
        {
            spcX = Integer.parseInt(content[21]);
        }
        if(content[13].length() > 0)
        {
            remotePort = Integer.parseInt(content[13]);
        }
        if(content[10].length() > 0)
        {
            serverPort = Integer.parseInt(content[10]);
        }
        if(content[22].length() > 0)
        {
            Text.set(content[22]);
        }
        moveOff = content[3].toUpperCase().equals("OFF");
        menuOff = content[7].toUpperCase().equals("OFF");
        path = content[1];
        engineOff = content[8].toUpperCase().equals("OFF");
        passwd = content[11];
        engine.xExecute(content[9]);
    }

    private void remoteControl(Socket socket)
    {
        SocketHandle sockethandle = new SocketHandle(socket, passwd);
        if(sockethandle.open())
        {
            String s;
            String s1;
            while(!(s1 = (s = sockethandle.read()).toUpperCase()).equals("QUIT")) 
            {
                if(engine.isSetup() || s1.equals("SETUPON"))
                {
                    if(!remoteCommand(s))
                    {
                        sockethandle.write(Text.ILLEGAL_PSN);
                    } else
                    if(!s1.equals("SETUPOFF"))
                    {
                        sockethandle.write(Text.OK_DOT);
                    } else
                    if(engine.gameEndFEN().equals(""))
                    {
                        sockethandle.write(Text.OK_DOT);
                    } else
                    {
                        sockethandle.write(engine.gameEndFEN());
                    }
                } else
                if(engine.isMove(s))
                {
                    if(!engine.gameEndFEN().equals(""))
                    {
                        sockethandle.write(engine.gameEndFEN());
                    } else
                    if(!remoteCommand(s))
                    {
                        sockethandle.write(Text.ILLEGAL_MOVE);
                    } else
                    if(!engine.gameEndFEN().equals(""))
                    {
                        sockethandle.write(engine.gameEndFEN());
                    } else
                    if(engine.isEdit())
                    {
                        sockethandle.write(Text.OK_DOT);
                    } else
                    {
                        remoteCommand("PLAY");
                        sockethandle.write(((MateEngine) (engine)).lineOut + "  " + engine.gameEndFEN());
                    }
                } else
                if(s.toUpperCase().equals("PLAY"))
                {
                    if(engine.gameEndFEN().equals(""))
                    {
                        remoteCommand("PLAY");
                        sockethandle.write(((MateEngine) (engine)).lineOut + "  " + engine.gameEndFEN());
                    } else
                    {
                        sockethandle.write(engine.gameEndFEN());
                    }
                } else
                if(s.toUpperCase().startsWith("MATE"))
                {
                    if(engine.gameEndFEN().equals(""))
                    {
                        remoteCommand(s);
                        sockethandle.write(((MateEngine) (engine)).lineOut + ((MateEngine) (engine)).valueOut + "  " + engine.gameEndFEN());
                    } else
                    {
                        sockethandle.write(engine.gameEndFEN());
                    }
                } else
                if(s.toUpperCase().equals("GETFEN"))
                {
                    sockethandle.write(engine.getFEN());
                } else
                if(s.toUpperCase().equals("GETGAME"))
                {
                    sockethandle.write(engine.gameString(true));
                } else
                {
                    remoteCommand(s);
                    if(engine.gameEndFEN().equals(""))
                    {
                        sockethandle.write("Ok.");
                    } else
                    {
                        sockethandle.write(engine.gameEndFEN());
                    }
                }
            }
            sockethandle.close();
        }
    }

    private void startRemoteServer()
    {
        Thread thread = new Thread() {

            public void run()
            {
                try
                {
                    rmtSocket = new ServerSocket(remotePort);
                }
                catch(SecurityException securityexception)
                {
                    System.out.println(Text.ILLEGAL_OP);
                }
                catch(IOException ioexception1)
                {
                    System.out.println(Text.OP_ERROR);
                }
                if(rmtSocket != null)
                {
                    System.out.println(Text.SERVER_STARTED);
                }
                while(rmtSocket != null) 
                {
                    try
                    {
                        Socket socket = rmtSocket.accept();
                        remoteControl(socket);
                    }
                    catch(IOException ioexception)
                    {
                        System.out.println(Text.OP_ERROR);
                    }
                    catch(SecurityException securityexception1)
                    {
                        System.out.println(Text.ILLEGAL_OP);
                    }
                }
                System.out.println(Text.SERVER_STOPPED);
            }

        };
        thread.start();
    }

    private void startChessServer()
    {
        server = new ChessServer(serverPort, passwd);
        server.start();
    }

    private void writeMonitor()
    {
        showStatus(((MateEngine) (engine)).plyOut + "/" + ((MateEngine) (engine)).totalNoOut + "/" + ((MateEngine) (engine)).noOut + " " + ((MateEngine) (engine)).lineOut + " " + ((MateEngine) (engine)).valueOut + " ");
    }

    private void stopMonitor()
    {
        monitor = false;
        if(!engineOff)
        {
            writeMonitor();
        }
    }

    private void startMonitor()
    {
        monitor = true;
        Thread thread = new Thread() {

            public void run()
            {
                while(monitor) 
                {
                    try
                    {
                        Thread.sleep(333L);
                    }
                    catch(InterruptedException interruptedexception) { }
                    writeMonitor();
                }
            }

        };
        thread.setPriority(6);
        thread.start();
    }

    private void drawToolBar(Graphics g)
    {
        g.setColor(whtColor);
        g.fillRect(barX, barY, barWidth, barHeight);
        g.drawImage(toolBar, barX, barY, this);
    }

    private void clearBackground(Graphics g)
    {
        g.clearRect(0, 0, 6, 1024);
        g.clearRect(sqrWidth * 8 + 6, 0, 256, 1024);
        g.clearRect(0, 0, 1024, 6);
        g.clearRect(0, sqrWidth * 8 + 6, 1024, 6);
    }

    public void init()
    {
        engine = new EngineHandle();
        engine.execute("NEW");
        bckColor = Color.decode("#101010");
        whtColor = Color.decode("#E0E0E0");
        blkColor = Color.decode("#A0A0A0");
        whtHighLight = Color.decode("#C0C0FF");
        blkHighLight = Color.decode("#9090BF");
        evaluatePARAM();
        lightsBoard = new boolean[64];
        beep = getAudioClip(getCodeBase(), path + "Beep.au");
        toolBar = getImage(getCodeBase(), path + "Toolbar.gif");
        wPawn = getImage(getCodeBase(), path + "WPawn.gif");
        bPawn = getImage(getCodeBase(), path + "BPawn.gif");
        wKnight = getImage(getCodeBase(), path + "WKnight.gif");
        bKnight = getImage(getCodeBase(), path + "BKnight.gif");
        wBishop = getImage(getCodeBase(), path + "WBishop.gif");
        bBishop = getImage(getCodeBase(), path + "BBishop.gif");
        wRook = getImage(getCodeBase(), path + "WRook.gif");
        bRook = getImage(getCodeBase(), path + "BRook.gif");
        wQueen = getImage(getCodeBase(), path + "WQueen.gif");
        bQueen = getImage(getCodeBase(), path + "BQueen.gif");
        wKing = getImage(getCodeBase(), path + "WKing.gif");
        bKing = getImage(getCodeBase(), path + "BKing.gif");
        while(wPawn == null || wPawn.getWidth(this) == -1) ;
        while(toolBar == null || toolBar.getWidth(this) == -1) ;
        while(toolBar == null || toolBar.getHeight(this) == -1) ;
        sqrWidth = wPawn.getWidth(this) + spcX;
        barWidth = toolBar.getWidth(this);
        barHeight = toolBar.getHeight(this);
        if(barX == 0)
        {
            barX = 8 * sqrWidth + 12;
        }
        if(barY == 0)
        {
            barY = 7 * sqrWidth + 6;
        }
        createMenu();
        add(popupMenu);
        add(setupMenu);
        addMouseListener(this);
        addMouseMotionListener(this);
        setBackground(bckColor);
        if(serverPort != 0)
        {
            startChessServer();
        }
        if(remotePort != 0)
        {
            startRemoteServer();
        }
    }

    public String getFEN()
    {
        return engine.getFEN();
    }

    public String getGAME()
    {
        return engine.gameString(true);
    }

    private char[] getGraphBoard()
    {
        String s = getFEN();
        String s1 = new String();
        if(rotate)
        {
            for(int i = 0; s.charAt(i) != ' '; i++)
            {
                if(s.charAt(i) == '-')
                {
                    s1 = s.charAt(i) + s1;
                } else
                if(s.charAt(i) > 'A')
                {
                    s1 = s.charAt(i) + s1;
                } else
                if(s.charAt(i) > '/')
                {
                    s1 = "        ".substring(0, s.charAt(i) - 48) + s1;
                }
            }

        }
        if(!rotate)
        {
            for(int j = 0; s.charAt(j) != ' '; j++)
            {
                if(s.charAt(j) == '-')
                {
                    s1 = s1 + s.charAt(j);
                } else
                if(s.charAt(j) > 'A')
                {
                    s1 = s1 + s.charAt(j);
                } else
                if(s.charAt(j) > '/')
                {
                    s1 = s1 + "        ".substring(0, s.charAt(j) - 48);
                }
            }

        }
        offsetX = 0;
        for(offsetY = 0; s1.startsWith("--------"); offsetY++)
        {
            s1 = s1.substring(8) + "--------";
        }

        while(s1.charAt(0) == '-' && s1.charAt(8) == '-' && s1.charAt(16) == '-' && s1.charAt(24) == '-' && s1.charAt(32) == '-' && s1.charAt(40) == '-' && s1.charAt(48) == '-' && s1.charAt(56) == '-') 
        {
            s1 = s1.substring(1, 8) + "-" + s1.substring(9, 16) + "-" + s1.substring(17, 24) + "-" + s1.substring(25, 32) + "-" + s1.substring(33, 40) + "-" + s1.substring(41, 48) + "-" + s1.substring(49, 56) + "-" + s1.substring(57, 64) + "-";
            offsetX++;
        }
        return s1.toCharArray();
    }

    private void drawSquare(Graphics g, char c, int i, boolean flag)
    {
        int j = i / 8;
        int k = i & 7;
        if(c == '-')
        {
            g.setColor(bckColor);
        } else
        {
            if((k + offsetX + j + offsetY & 1) == 0)
            {
                g.setColor(whtColor);
            } else
            {
                g.setColor(blkColor);
            }
            if(flag)
            {
                if((k + offsetX + j + offsetY & 1) == 0)
                {
                    g.setColor(whtHighLight);
                } else
                {
                    g.setColor(blkHighLight);
                }
                lightsBoard[i] = true;
            } else
            {
                lightsBoard[i] = false;
            }
        }
        g.fillRect(6 + k * sqrWidth, 6 + j * sqrWidth, sqrWidth, sqrWidth);
    }

    private void drawFigure(Graphics g, char c, int i, int j)
    {
        if(c == 'P')
        {
            g.drawImage(wPawn, i, j, this);
        }
        if(c == 'p')
        {
            g.drawImage(bPawn, i, j, this);
        }
        if(c == 'N')
        {
            g.drawImage(wKnight, i, j, this);
        }
        if(c == 'n')
        {
            g.drawImage(bKnight, i, j, this);
        }
        if(c == 'B')
        {
            g.drawImage(wBishop, i, j, this);
        }
        if(c == 'b')
        {
            g.drawImage(bBishop, i, j, this);
        }
        if(c == 'R')
        {
            g.drawImage(wRook, i, j, this);
        }
        if(c == 'r')
        {
            g.drawImage(bRook, i, j, this);
        }
        if(c == 'Q')
        {
            g.drawImage(wQueen, i, j, this);
        }
        if(c == 'q')
        {
            g.drawImage(bQueen, i, j, this);
        }
        if(c == 'K')
        {
            g.drawImage(wKing, i, j, this);
        }
        if(c == 'k')
        {
            g.drawImage(bKing, i, j, this);
        }
    }

    private void drawFigure(Graphics g, char c, int i)
    {
        int j = (i & 7) * sqrWidth + 6;
        int k = (i / 8) * sqrWidth + 6;
        drawFigure(g, c, j + spcX / 2, k + spcX / 2);
    }

    private void drawBoard(Graphics g, char ac[], char ac1[], boolean flag, int i)
    {
        if(i != 2)
        {
            for(int j = 0; j < 64; j++)
            {
                if(lightsBoard[j])
                {
                    drawSquare(g, ac1[j], j, false);
                    if(!blind)
                    {
                        drawFigure(g, ac1[j], j);
                    }
                }
            }

        }
        for(int k = 0; k < 64; k++)
        {
            if(flag || ac[k] != ac1[k])
            {
                drawSquare(g, ac1[k], k, i == 1 || lightsBoard[k]);
                if(!blind)
                {
                    drawFigure(g, ac1[k], k);
                }
            }
        }

        drawToolBar(g);
    }

    public void paint(Graphics g)
    {
        char ac[] = new char[64];
        char ac1[] = getGraphBoard();
        if(dragging)
        {
            ac = getGraphBoard();
        }
        if(dragging)
        {
            if(rotate)
            {
                ac1[63 - fromBoard - offsetX - offsetY * 8] = ' ';
            } else
            {
                ac1[fromBoard - offsetX - offsetY * 8] = ' ';
            }
        }
        clearBackground(g);
        drawBoard(g, ac, ac1, true, 2);
        if(dragging && !blind)
        {
            if(rotate)
            {
                drawFigure(getGraphics(), ac[63 - fromBoard - offsetX - offsetY * 8], dragX, dragY);
            } else
            {
                drawFigure(getGraphics(), ac[fromBoard - offsetX - offsetY * 8], dragX, dragY);
            }
        }
    }

    public void update(Graphics g)
    {
        char ac[] = new char[64];
        char ac1[] = getGraphBoard();
        if(dragging)
        {
            ac = getGraphBoard();
            int i;
            if(rotate)
            {
                i = 63 - fromBoard - offsetX - offsetY * 8;
            } else
            {
                i = fromBoard - offsetX - offsetY * 8;
            }
            if(ac1[i] != '-')
            {
                ac1[i] = ' ';
            }
        }
        clearBackground(g);
        if(dragging)
        {
            drawBoard(g, ac, ac1, true, 2);
        } else
        {
            drawBoard(g, ac, ac1, false, 2);
        }
        if(dragging && !blind)
        {
            if(rotate)
            {
                drawFigure(getGraphics(), ac[63 - fromBoard - offsetX - offsetY * 8], dragX, dragY);
            } else
            {
                drawFigure(getGraphics(), ac[fromBoard - offsetX - offsetY * 8], dragX, dragY);
            }
        }
    }

    private void messageBox(String s, String s1)
    {
        dialog = new Dialog(new Frame(""), s, true);
        Button button = new Button("Ok") {

            public Dimension getPreferredsqrX()
            {
                return new Dimension(60, 20);
            }

        };
        button.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                dialog.setVisible(false);
            }

        });
        dialog.addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent windowevent)
            {
                dialog.setVisible(false);
            }

        });
        dialog.add(new Label(s1));
        dialog.add(button);
        dialog.setLayout(new FlowLayout());
        dialog.setLocation(325, 250);
        dialog.pack();
        dialog.show();
    }

    private void createMenu()
    {
        popupMenu = new PopupMenu(Text.MENU);
        setupMenu = new PopupMenu(Text.SETUP);
        depthMenu = new Menu(Text.SEARCH_DEPTH);
        extendMenu = new Menu(Text.EXTEND_DEPTH);
        timeMenu = new Menu(Text.TIME_LIMIT);
        mateMenu = new Menu(Text.MATE);
        levelMenu = new Menu(Text.LEVEL);
        gameMenu = new Menu(Text.GAME);
        boardMenu = new Menu(Text.VIEW);
        modeMenu = new Menu(Text.MODE);
        fairyMenu = new Menu(Text.VARIANTS);
        boardMenu.add(Text.ROTATE);
        boardMenu.add(Text.BLIND);
        setupMenu.add(Text.SWITCH);
        setupMenu.add(Text.CLEAR);
        setupMenu.add(Text.SETNEW);
        setupMenu.add(Text.SETUPOFF);
        depthMenu.add(Text.ONE_PLY);
        depthMenu.add(Text.TWO_PLYS);
        depthMenu.add(Text.THREE_PLYS);
        depthMenu.add(Text.FOUR_PLYS);
        depthMenu.add(Text.FIVE_PLYS);
        extendMenu.add(Text.ONE_PLY);
        extendMenu.add(Text.TWO_PLYS);
        extendMenu.add(Text.THREE_PLYS);
        extendMenu.add(Text.FOUR_PLYS);
        extendMenu.add(Text.FIVE_PLYS);
        extendMenu.add(Text.SIX_PLYS);
        extendMenu.add(Text.SEVEN_PLYS);
        mateMenu.add(Text.MATE_IN_ONE);
        mateMenu.add(Text.MATE_IN_TWO);
        mateMenu.add(Text.MATE_IN_THREE);
        mateMenu.add(Text.MATE_IN_FOUR);
        mateMenu.add(Text.MATE_IN_FIVE);
        mateMenu.add(Text.MATE_IN_SIX);
        mateMenu.add(Text.MATE_IN_SEVEN);
        mateMenu.add(Text.FIND_NEXT_MATE);
        timeMenu.add(Text.FIVE_SEC);
        timeMenu.add(Text.TEN_SEC);
        timeMenu.add(Text.THIRTY_SEC);
        timeMenu.add(Text.ONE_MIN);
        timeMenu.add(Text.THREE_MIN);
        gameMenu.add(Text.NEWGAME);
        gameMenu.add(Text.BACK);
        gameMenu.add(Text.FORWARD);
        gameMenu.add(Text.END);
        gameMenu.add(Text.BEGIN);
        fairyMenu.add(Text.ALAMOS);
        fairyMenu.add(Text.COURTYARD);
        fairyMenu.add(Text.DIANA);
        fairyMenu.add(Text.UPSIDE_DOWN);
        fairyMenu.add(Text.THIRTY_SEVEN);
        modeMenu.add(fairyMenu);
        modeMenu.add(Text.PLAY);
        modeMenu.add(Text.MEMORY);
        modeMenu.add(Text.SETUPON);
        levelMenu.add(depthMenu);
        levelMenu.add(extendMenu);
        levelMenu.add(timeMenu);
        popupMenu.add(gameMenu);
        popupMenu.add(modeMenu);
        popupMenu.addSeparator();
        popupMenu.add(boardMenu);
        popupMenu.addSeparator();
        popupMenu.add(mateMenu);
        popupMenu.add(levelMenu);
        popupMenu.addSeparator();
        popupMenu.add(Text.INFO);
        fairyMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.DIANA.equals(actionevent.getActionCommand()))
                {
                    executeCommandLine("FEN --------/rbnkbr--/pppppp--/6--/6--/PPPPPP--/RBNKBR--/-------- w kKqQ - 0 1; " +
" NODOUBLE;   CASTLE; FAIRY; PRMTO {NBR}; TARGET[22223333];"
);
                }
                if(Text.COURTYARD.equals(actionevent.getActionCommand()))
                {
                    executeCommandLine("FEN rnknr---/pbqbp---/1ppp1---/5---/5---/1PPP1---/PBQBP---/RNKNR--- w kKqQ - 0 1" +
";  DOUBLE;   CASTLE; FAIRY; PRMTO{NBRQ}; TARGET[12121212];"
);
                }
                if(Text.ALAMOS.equals(actionevent.getActionCommand()))
                {
                    executeCommandLine("FEN --------/rnqknr--/pppppp--/6--/6--/PPPPPP--/RNQKNR--/-------- w - - 0 1;    " +
" NODOUBLE; NOCASTLE; FAIRY; PRMTO{NBRQ};"
);
                }
                if(Text.UPSIDE_DOWN.equals(actionevent.getActionCommand()))
                {
                    executeCommandLine("FEN RNBQKBNR/PPPPPPPP/8/8/8/8/pppppppp/rnbqkbnr w - - 0 1;                      " +
"   DOUBLE;           FAIRY; PRMTO{NBRQ};"
);
                }
                if(Text.THIRTY_SEVEN.equals(actionevent.getActionCommand()))
                {
                    executeCommandLine("FEN --qbk---/-rnbnr--/ppppppp-/7-/PPPPPPP-/-RNBNR--/--QBK---/-------- w - - 0 1;" +
" NODOUBLE; NOCASTLE; FAIRY; PRMTO{NBRQ}; PRMNOTAHD;"
);
                }
            }

        });
        mateMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.MATE_IN_ONE.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MATE 1");
                }
                if(Text.MATE_IN_TWO.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MATE 2");
                }
                if(Text.MATE_IN_THREE.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MATE 3");
                }
                if(Text.MATE_IN_FOUR.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MATE 4");
                }
                if(Text.MATE_IN_FIVE.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MATE 5");
                }
                if(Text.MATE_IN_SIX.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MATE 6");
                }
                if(Text.MATE_IN_SEVEN.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MATE 7");
                }
                if(Text.FIND_NEXT_MATE.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MATE 0");
                }
            }

        });
        modeMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.PLAY.equals(actionevent.getActionCommand()))
                {
                    executeCommand("PLAY");
                }
                if(Text.MEMORY.equals(actionevent.getActionCommand()))
                {
                    executeCommand("MEMORY");
                }
                if(Text.SETUPON.equals(actionevent.getActionCommand()))
                {
                    executeCommand("SETUPON");
                }
            }

        });
        popupMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.INFO.equals(actionevent.getActionCommand()))
                {
                    messageBox("JavaChessGame", "Program");
                }
            }

        });
        setupMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.SETUPOFF.equals(actionevent.getActionCommand()))
                {
                    executeCommand("SETUPOFF");
                }
                if(Text.CLEAR.equals(actionevent.getActionCommand()))
                {
                    executeCommand("CLEAR");
                }
                if(Text.SETNEW.equals(actionevent.getActionCommand()))
                {
                    executeCommand("SETNEW");
                }
                if(Text.SWITCH.equals(actionevent.getActionCommand()))
                {
                    executeCommand("SWITCH");
                }
            }

        });
        boardMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.ROTATE.equals(actionevent.getActionCommand()))
                {
                    executeCommand("ROTATE");
                }
                if(Text.BLIND.equals(actionevent.getActionCommand()))
                {
                    executeCommand("BLIND");
                }
            }

        });
        gameMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.NEWGAME.equals(actionevent.getActionCommand()))
                {
                    executeCommand("NEW");
                }
                if(Text.BACK.equals(actionevent.getActionCommand()))
                {
                    executeCommand("BACK");
                }
                if(Text.FORWARD.equals(actionevent.getActionCommand()))
                {
                    executeCommand("FORWARD");
                }
                if(Text.BEGIN.equals(actionevent.getActionCommand()))
                {
                    executeCommand("BEGIN");
                }
                if(Text.END.equals(actionevent.getActionCommand()))
                {
                    executeCommand("END");
                }
            }

        });
        depthMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.ONE_PLY.equals(actionevent.getActionCommand()))
                {
                    executeCommand("PLY 1");
                }
                if(Text.TWO_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("PLY 2");
                }
                if(Text.THREE_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("PLY 3");
                }
                if(Text.FOUR_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("PLY 4");
                }
                if(Text.FIVE_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("PLY 5");
                }
            }

        });
        extendMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.ONE_PLY.equals(actionevent.getActionCommand()))
                {
                    executeCommand("XPLY 1");
                }
                if(Text.TWO_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("XPLY 2");
                }
                if(Text.THREE_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("XPLY 3");
                }
                if(Text.FOUR_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("XPLY 4");
                }
                if(Text.FIVE_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("XPLY 5");
                }
                if(Text.SIX_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("XPLY 6");
                }
                if(Text.SEVEN_PLYS.equals(actionevent.getActionCommand()))
                {
                    executeCommand("XPLY 7");
                }
            }

        });
        timeMenu.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                if(Text.FIVE_SEC.equals(actionevent.getActionCommand()))
                {
                    executeCommand("TIME 50");
                }
                if(Text.TEN_SEC.equals(actionevent.getActionCommand()))
                {
                    executeCommand("TIME 100");
                }
                if(Text.THIRTY_SEC.equals(actionevent.getActionCommand()))
                {
                    executeCommand("TIME 300");
                }
                if(Text.ONE_MIN.equals(actionevent.getActionCommand()))
                {
                    executeCommand("TIME 600");
                }
                if(Text.THREE_MIN.equals(actionevent.getActionCommand()))
                {
                    executeCommand("TIME 1800");
                }
            }

        });
    }

    private char promoteTo(String s)
    {
        dialog = new Dialog(new Frame(""), Text.PROMOTION, true);
        CheckboxGroup checkboxgroup = new CheckboxGroup();
        Checkbox checkbox = new Checkbox(Text.KNIGHT, checkboxgroup, false);
        Checkbox checkbox1 = new Checkbox(Text.BISHOP, checkboxgroup, false);
        Checkbox checkbox2 = new Checkbox(Text.ROOK, checkboxgroup, false);
        Checkbox checkbox3 = new Checkbox(Text.QUEEN, checkboxgroup, false);
        Button button = new Button(Text.OK_BUTTON) {

            public Dimension getPreferredsize()
            {
                return new Dimension(60, 20);
            }

        };
        Panel panel = new Panel();
        panel.setLayout(new FlowLayout(1));
        panel.add(button);
        dialog.setLayout(new GridLayout(4, 2));
        dialog.setSize(200, 150);
        dialog.setLocation(300, 225);
        dialog.addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent windowevent)
            {
                dialog.setVisible(false);
            }

        });
        button.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent actionevent)
            {
                dialog.setVisible(false);
            }

        });
        if(s.equals(""))
        {
            return ' ';
        }
        checkbox.addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent itemevent)
            {
                promotePiece = 'N';
            }

        });
        checkbox1.addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent itemevent)
            {
                promotePiece = 'B';
            }

        });
        checkbox2.addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent itemevent)
            {
                promotePiece = 'R';
            }

        });
        checkbox3.addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent itemevent)
            {
                promotePiece = 'Q';
            }

        });
        dialog.add(checkbox);
        dialog.add(panel);
        dialog.add(checkbox1);
        dialog.add(new Label());
        dialog.add(checkbox2);
        dialog.add(new Label());
        dialog.add(checkbox3);
        dialog.add(new Label());
        if(s.indexOf("Q") == -1)
        {
            checkbox3.setEnabled(false);
        }
        if(s.indexOf("R") == -1)
        {
            checkbox2.setEnabled(false);
        }
        if(s.indexOf("B") == -1)
        {
            checkbox1.setEnabled(false);
        }
        if(s.indexOf("N") == -1)
        {
            checkbox.setEnabled(false);
        }
        dialog.show();
        return promotePiece;
    }

    private void checkEnd()
    {
        String s = engine.gameEndFEN();
        if(s.equals("MATE"))
        {
            messageBox(Text.GAME_END, Text.CHECKMATE);
        }
        if(s.equals("STALEMATE"))
        {
            messageBox(Text.GAME_END, Text.STALEMATE);
        }
        if(s.equals("MATERIAL"))
        {
            messageBox(Text.GAME_END, Text.FEW_MATERIAL);
        }
        if(s.equals("FIFTY MOVES"))
        {
            messageBox(Text.GAME_END, Text.FIFTY_MOVES);
        }
        if(s.equals("THIRD REPETITION"))
        {
            messageBox(Text.GAME_END, Text.THIRD_REPETITION);
        }
    }

    private boolean execute(String s)
    {
        String s1 = s.toUpperCase();
        if(engine.isMove(s) && !moveOff)
        {
            return engine.execute(s);
        }
        if(s1.equals("NEXT"))
        {
            return engine.execute("NEXT " + fromString(fromBoard));
        }
        if(s1.equals("PLAY"))
        {
            if(engineOff)
            {
                return true;
            }
            startMonitor();
        }
        if(s1.startsWith("MATE"))
        {
            if(engineOff)
            {
                return true;
            }
            startMonitor();
        }
        boolean flag = engine.execute(s);
        if(s1.equals("PLAY"))
        {
            stopMonitor();
        }
        if(s1.startsWith("MATE"))
        {
            stopMonitor();
        }
        return flag;
    }

    private void executeCommandLine(String s)
    {
        int i = 0;
        boolean flag = s.indexOf("PLAY") != -1 || s.indexOf("MATE") != -1 || s.indexOf("BLIND") != -1 || s.indexOf("ROTATE") != -1;
        boolean flag1 = s.indexOf("BLIND") != -1 || s.indexOf("ROTATE") != -1 || s.indexOf("FEN") != -1;
        if(flag)
        {
            executeCommand(s);
            return;
        }
        if(s.equals("PLAY") || s.startsWith("MATE") || s.startsWith("FORWARD"))
        {
            i = 1;
        }
        char ac[] = getGraphBoard();
        boolean flag2 = engine.xExecute(s);
        char ac1[] = getGraphBoard();
        drawBoard(getGraphics(), ac, ac1, flag1, i);
        if(!engine.isSetup())
        {
            checkEnd();
        }
        beep.play();
    }

    public synchronized boolean remoteCommand(String s)
    {
        String s1 = s.toUpperCase();
        setCursor(new Cursor(3));
        char ac[] = getGraphBoard();
        boolean flag = execute(s);
        char ac1[] = getGraphBoard();
        setCursor(new Cursor(0));
        int i = 0;
        if(s1.equals("PLAY") || s1.startsWith("MATE") || s1.startsWith("FORWARD"))
        {
            i = 1;
        }
        drawBoard(getGraphics(), ac, ac1, s1.equals("BLIND") || s1.equals("ROTATE"), i);
        return flag;
    }

    public synchronized boolean executeCommand(String s)
    {
        String s1 = s.toUpperCase();
        if(s1.equals("BLIND"))
        {
            blind = !blind;
        }
        if(s1.equals("ROTATE"))
        {
            rotate = !rotate;
        }
        boolean flag = remoteCommand(s);
        if(s1.equals("SETUPOFF"))
        {
            if(!engine.isSetup())
            {
                checkEnd();
            } else
            {
                messageBox(Text.WARNING, Text.ILLEGAL_PSN);
            }
        }
        if(s1.equals("END") || s1.equals("FORWARD"))
        {
            checkEnd();
        }
        if(s1.startsWith("MATE") || s1.equals("PLAY"))
        {
            checkEnd();
        }
        beep.play();
        return flag;
    }

    private int sqrPsn(MouseEvent mouseevent)
    {
        return (mouseevent.getX() - 6) / sqrWidth + offsetX + ((mouseevent.getY() - 6) / sqrWidth + offsetY) * 8;
    }

    private String fromString(int i)
    {
        return "" + (char)(97 + i % 8) + (char)(56 - i / 8);
    }

    private String toString(int i)
    {
        return "" + (char)(97 + i % 8) + (char)(56 - i / 8);
    }

    private String moveString(int i, int j)
    {
        return fromString(i) + toString(j);
    }

    private boolean executeToolBar(MouseEvent mouseevent)
    {
        if(mouseevent.getY() > barY && mouseevent.getY() < barY + barHeight && mouseevent.getX() < barX + barWidth)
        {
            if(mouseevent.getX() > (barWidth * 4) / 5 + barX)
            {
                executeCommandLine(content[18]);
            } else
            if(mouseevent.getX() > (barWidth * 3) / 5 + barX)
            {
                executeCommandLine(content[17]);
            } else
            if(mouseevent.getX() > (barWidth * 2) / 5 + barX)
            {
                executeCommandLine(content[16]);
            } else
            if(mouseevent.getX() > (barWidth * 1) / 5 + barX)
            {
                executeCommandLine(content[15]);
            } else
            if(mouseevent.getX() > (barWidth * 0) / 5 + barX)
            {
                executeCommandLine(content[14]);
            } else
            {
                return false;
            }
            return true;
        } else
        {
            return false;
        }
    }

    private void rightButton(MouseEvent mouseevent)
    {
        if(!menuOff)
        {
            if(engine.isSetup())
            {
                setupMenu.show(this, mouseevent.getX(), mouseevent.getY());
            } else
            {
                popupMenu.show(this, mouseevent.getX(), mouseevent.getY());
            }
        }
    }

    private void leftButton(MouseEvent mouseevent)
    {
        if(rotate)
        {
            toBoard = 63 - sqrPsn(mouseevent);
        } else
        {
            toBoard = sqrPsn(mouseevent);
        }
        String s = moveString(fromBoard, toBoard);
        String s1 = engine.isPromotion(s);
        int i = (fromBoard - offsetX - offsetY * 8 & 7) * sqrWidth + 6;
        int j = ((fromBoard - offsetX - offsetY * 8) / 8) * sqrWidth + 6;
        if(rotate)
        {
            i = (63 - fromBoard - offsetX - offsetY * 8 & 7) * sqrWidth + 6;
        }
        if(rotate)
        {
            j = ((63 - fromBoard - offsetX - offsetY * 8) / 8) * sqrWidth + 6;
        }
        dragX = mouseevent.getX() - sqrWidth / 2;
        dragging = false;
        dragY = mouseevent.getY() - sqrWidth / 2;
        repaint(dragX, dragY, sqrWidth, sqrWidth);
        repaint(i, j, sqrWidth, sqrWidth);
        if(!engine.isSetup())
        {
            if(s1.equals(""))
            {
                s = s + "  ";
            } else
            {
                s = s + promoteTo(s1) + " ";
            }
        }
        if(!executeToolBar(mouseevent))
        {
            if(engine.isSetup())
            {
                executeCommand("NEXT");
            } else
            if(fromBoard != toBoard && !moveOff)
            {
                if(!engine.gameEndFEN().equals(""))
                {
                    checkEnd();
                } else
                if(!executeCommand(s))
                {
                    messageBox(Text.WARNING, Text.ILLEGAL_MOVE);
                } else
                if(engine.isEdit())
                {
                    checkEnd();
                } else
                {
                    executeCommand("PLAY");
                }
            }
        }
    }

    public void mousePressed(MouseEvent mouseevent)
    {
        if(rotate)
        {
            fromBoard = 63 - sqrPsn(mouseevent);
        } else
        {
            fromBoard = sqrPsn(mouseevent);
        }
        if(mouseevent.getModifiers() == 16 && mouseevent.getX() > 5 && mouseevent.getX() < sqrWidth * 8 + 6 && mouseevent.getY() > 5 && mouseevent.getY() < sqrWidth * 8 + 6)
        {
            int i = (sqrPsn(mouseevent) - offsetX - offsetY * 8 & 7) * sqrWidth + 6;
            int j = ((sqrPsn(mouseevent) - offsetX - offsetY * 8) / 8) * sqrWidth + 6;
            dragX = mouseevent.getX() - sqrWidth / 2;
            dragY = mouseevent.getY() - sqrWidth / 2;
            if(!engine.isSetup())
            {
                dragging = true;
            }
            if(!engine.isSetup())
            {
                repaint(Math.min(dragX, i), Math.min(dragY, j), sqrWidth + sqrWidth / 2, sqrWidth + sqrWidth / 2);
            }
        }
    }

    public void mouseReleased(MouseEvent mouseevent)
    {
        if(mouseevent.getModifiers() == 4)
        {
            rightButton(mouseevent);
        }
        if(mouseevent.getModifiers() == 16)
        {
            leftButton(mouseevent);
        }
    }

    public void mouseDragged(MouseEvent mouseevent)
    {
        char ac[] = getGraphBoard();
        int i = dragX;
        int j = dragY;
        dragX = mouseevent.getX() - sqrWidth / 2;
        dragY = mouseevent.getY() - sqrWidth / 2;
        if(!engine.isSetup())
        {
            repaint(Math.min(dragX, i), Math.min(dragY, j), sqrWidth + Math.abs(dragX - i), sqrWidth + Math.abs(dragY - j));
        }
    }




}
