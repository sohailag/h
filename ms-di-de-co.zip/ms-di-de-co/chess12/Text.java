public class Text
{

    public static String MENU = "Menu";
    public static String SETUP = "Setup";
    public static String GAME = "Game";
    public static String MODE = "Mode";
    public static String VIEW = "View";
    public static String MATE = "Mate";
    public static String LEVEL = "Level";
    public static String INFO = "Info";
    public static String NEWGAME = "New Game";
    public static String BACK = "Back";
    public static String FORWARD = "Forward";
    public static String END = "End";
    public static String BEGIN = "Begin";
    public static String VARIANTS = "Variants";
    public static String ALAMOS = "Alamos";
    public static String COURTYARD = "Courtyard";
    public static String DIANA = "Diana";
    public static String UPSIDE_DOWN = "Upside Down";
    public static String THIRTY_SEVEN = "Thirty Seven";
    public static String PLAY = "Play";
    public static String MEMORY = "Memory";
    public static String SETUPON = "Setup on";
    public static String SWITCH = "Switch";
    public static String CLEAR = "Clear";
    public static String SETNEW = "Set New";
    public static String SETUPOFF = "Setup Off";
    public static String ROTATE = "Rotate";
    public static String BLIND = "Blind";
    public static String MATE_IN_ONE = "Mate in one";
    public static String MATE_IN_TWO = "Mate in two";
    public static String MATE_IN_THREE = "Mate in three";
    public static String MATE_IN_FOUR = "Mate in four";
    public static String MATE_IN_FIVE = "Mate in five";
    public static String MATE_IN_SIX = "Mate in six";
    public static String MATE_IN_SEVEN = "Mate in seven";
    public static String FIND_NEXT_MATE = "Find next Mate";
    public static String SEARCH_DEPTH = "Search Depth";
    public static String EXTEND_DEPTH = "Extend Depth";
    public static String TIME_LIMIT = "Time Limit";
    public static String ONE_PLY = "One player";
    public static String TWO_PLYS = "two player";
    public static String THREE_PLYS = "three player";
    public static String FOUR_PLYS = "four player";
    public static String FIVE_PLYS = "five player";
    public static String SIX_PLYS = "six player";
    public static String SEVEN_PLYS = "seven player";
    public static String FIVE_SEC = "Five Seconds";
    public static String TEN_SEC = "Six Seconds";
    public static String THIRTY_SEC = "Thirty Seconds";
    public static String ONE_MIN = "One Minute";
    public static String THREE_MIN = "Three Minute";
    public static String PAWN = "Pawn";
    public static String KNIGHT = "Knight";
    public static String BISHOP = "Bishop";
    public static String ROOK = "Rook";
    public static String QUEEN = "Queen";
    public static String KING = "King";
    public static String GAME_END = "Game End";
    public static String CHECKMATE = "CheckMate";
    public static String STALEMATE = "Stalemate";
    public static String FEW_MATERIAL = "Few material";
    public static String FIFTY_MOVES = "fifty moves";
    public static String THIRD_REPETITION = "third repetition";
    public static String ILLEGAL_PSN = "illegal psn.";
    public static String ILLEGAL_MOVE = "Illegal Move.";
    public static String PROMOTION = "Promotion";
    public static String WARNING = "Warning";
    public static String OK_BUTTON = " Ok ";
    public static String MATE_IN = "Matt in ";
    public static String NO_MATE = "No Mate";
    public static String NO_MORE_MATE = "No more mate";
    public static String ILLEGAL_OP = "Illegal Option.";
    public static String OP_ERROR = "I/O Error.";
    public static String READ_ERROR = "Read error.";
    public static String CON_ERROR = "Con Error.";
    public static String CON_CLOSED = "Connection closed.";
    public static String CON_OPENED = "Con Opened.";
    public static String OK_DOT = "Ok.";
    public static String ENTER_PWD = "Password:";
    public static String SERVER_STARTED = "Server started.";
    public static String SERVER_STOPPED = "Server Stopped.";

    public Text()
    {
    }

    private static String getEntry(String s, int i)
    {
        String s1 = "";
        char c = s.charAt(0);
        while(i-- > 0) 
        {
            if(s.indexOf(c) == -1)
            {
                return "";
            }
            s = s.substring(s.indexOf(c) + 1);
            if(s.indexOf(c) == -1)
            {
                return "";
            }
        }
        return s.substring(0, s.indexOf(c));
    }

    static void set(String s)
    {
        if(!getEntry(s, 1).equals(""))
        {
            MENU = getEntry(s, 1);
        }
        if(!getEntry(s, 2).equals(""))
        {
            SETUP = getEntry(s, 2);
        }
        if(!getEntry(s, 3).equals(""))
        {
            GAME = getEntry(s, 3);
        }
        if(!getEntry(s, 4).equals(""))
        {
            MODE = getEntry(s, 4);
        }
        if(!getEntry(s, 5).equals(""))
        {
            VIEW = getEntry(s, 5);
        }
        if(!getEntry(s, 6).equals(""))
        {
            MATE = getEntry(s, 6);
        }
        if(!getEntry(s, 7).equals(""))
        {
            LEVEL = getEntry(s, 7);
        }
        if(!getEntry(s, 8).equals(""))
        {
            INFO = getEntry(s, 8);
        }
        if(!getEntry(s, 9).equals(""))
        {
            NEWGAME = getEntry(s, 9);
        }
        if(!getEntry(s, 10).equals(""))
        {
            BACK = getEntry(s, 10);
        }
        if(!getEntry(s, 11).equals(""))
        {
            FORWARD = getEntry(s, 11);
        }
        if(!getEntry(s, 12).equals(""))
        {
            END = getEntry(s, 12);
        }
        if(!getEntry(s, 13).equals(""))
        {
            BEGIN = getEntry(s, 13);
        }
        if(!getEntry(s, 14).equals(""))
        {
            VARIANTS = getEntry(s, 14);
        }
        if(!getEntry(s, 15).equals(""))
        {
            ALAMOS = getEntry(s, 15);
        }
        if(!getEntry(s, 16).equals(""))
        {
            COURTYARD = getEntry(s, 16);
        }
        if(!getEntry(s, 17).equals(""))
        {
            DIANA = getEntry(s, 17);
        }
        if(!getEntry(s, 18).equals(""))
        {
            UPSIDE_DOWN = getEntry(s, 18);
        }
        if(!getEntry(s, 19).equals(""))
        {
            THIRTY_SEVEN = getEntry(s, 19);
        }
        if(!getEntry(s, 20).equals(""))
        {
            PLAY = getEntry(s, 20);
        }
        if(!getEntry(s, 21).equals(""))
        {
            MEMORY = getEntry(s, 21);
        }
        if(!getEntry(s, 22).equals(""))
        {
            SETUPON = getEntry(s, 22);
        }
        if(!getEntry(s, 23).equals(""))
        {
            SWITCH = getEntry(s, 23);
        }
        if(!getEntry(s, 24).equals(""))
        {
            CLEAR = getEntry(s, 24);
        }
        if(!getEntry(s, 25).equals(""))
        {
            SETNEW = getEntry(s, 25);
        }
        if(!getEntry(s, 26).equals(""))
        {
            SETUPOFF = getEntry(s, 26);
        }
        if(!getEntry(s, 27).equals(""))
        {
            ROTATE = getEntry(s, 27);
        }
        if(!getEntry(s, 28).equals(""))
        {
            BLIND = getEntry(s, 28);
        }
        if(!getEntry(s, 29).equals(""))
        {
            MATE_IN_ONE = getEntry(s, 29);
        }
        if(!getEntry(s, 30).equals(""))
        {
            MATE_IN_TWO = getEntry(s, 30);
        }
        if(!getEntry(s, 31).equals(""))
        {
            MATE_IN_THREE = getEntry(s, 31);
        }
        if(!getEntry(s, 32).equals(""))
        {
            MATE_IN_FOUR = getEntry(s, 32);
        }
        if(!getEntry(s, 33).equals(""))
        {
            MATE_IN_FIVE = getEntry(s, 33);
        }
        if(!getEntry(s, 34).equals(""))
        {
            MATE_IN_SIX = getEntry(s, 34);
        }
        if(!getEntry(s, 35).equals(""))
        {
            MATE_IN_SEVEN = getEntry(s, 35);
        }
        if(!getEntry(s, 36).equals(""))
        {
            FIND_NEXT_MATE = getEntry(s, 36);
        }
        if(!getEntry(s, 37).equals(""))
        {
            SEARCH_DEPTH = getEntry(s, 37);
        }
        if(!getEntry(s, 38).equals(""))
        {
            EXTEND_DEPTH = getEntry(s, 38);
        }
        if(!getEntry(s, 39).equals(""))
        {
            TIME_LIMIT = getEntry(s, 39);
        }
        if(!getEntry(s, 40).equals(""))
        {
            ONE_PLY = getEntry(s, 40);
        }
        if(!getEntry(s, 41).equals(""))
        {
            TWO_PLYS = getEntry(s, 41);
        }
        if(!getEntry(s, 42).equals(""))
        {
            THREE_PLYS = getEntry(s, 42);
        }
        if(!getEntry(s, 43).equals(""))
        {
            FOUR_PLYS = getEntry(s, 43);
        }
        if(!getEntry(s, 44).equals(""))
        {
            FIVE_PLYS = getEntry(s, 44);
        }
        if(!getEntry(s, 45).equals(""))
        {
            SIX_PLYS = getEntry(s, 45);
        }
        if(!getEntry(s, 46).equals(""))
        {
            SEVEN_PLYS = getEntry(s, 46);
        }
        if(!getEntry(s, 47).equals(""))
        {
            FIVE_SEC = getEntry(s, 47);
        }
        if(!getEntry(s, 48).equals(""))
        {
            TEN_SEC = getEntry(s, 48);
        }
        if(!getEntry(s, 49).equals(""))
        {
            THIRTY_SEC = getEntry(s, 49);
        }
        if(!getEntry(s, 50).equals(""))
        {
            ONE_MIN = getEntry(s, 50);
        }
        if(!getEntry(s, 51).equals(""))
        {
            THREE_MIN = getEntry(s, 51);
        }
        if(!getEntry(s, 52).equals(""))
        {
            PAWN = getEntry(s, 52);
        }
        if(!getEntry(s, 53).equals(""))
        {
            KNIGHT = getEntry(s, 53);
        }
        if(!getEntry(s, 54).equals(""))
        {
            BISHOP = getEntry(s, 54);
        }
        if(!getEntry(s, 55).equals(""))
        {
            ROOK = getEntry(s, 55);
        }
        if(!getEntry(s, 56).equals(""))
        {
            QUEEN = getEntry(s, 56);
        }
        if(!getEntry(s, 57).equals(""))
        {
            KING = getEntry(s, 57);
        }
        if(!getEntry(s, 58).equals(""))
        {
            GAME_END = getEntry(s, 58);
        }
        if(!getEntry(s, 59).equals(""))
        {
            CHECKMATE = getEntry(s, 59);
        }
        if(!getEntry(s, 60).equals(""))
        {
            STALEMATE = getEntry(s, 60);
        }
        if(!getEntry(s, 61).equals(""))
        {
            FEW_MATERIAL = getEntry(s, 61);
        }
        if(!getEntry(s, 62).equals(""))
        {
            FIFTY_MOVES = getEntry(s, 62);
        }
        if(!getEntry(s, 63).equals(""))
        {
            THIRD_REPETITION = getEntry(s, 63);
        }
        if(!getEntry(s, 64).equals(""))
        {
            ILLEGAL_PSN = getEntry(s, 64);
        }
        if(!getEntry(s, 65).equals(""))
        {
            ILLEGAL_MOVE = getEntry(s, 65);
        }
        if(!getEntry(s, 66).equals(""))
        {
            PROMOTION = getEntry(s, 66);
        }
        if(!getEntry(s, 67).equals(""))
        {
            WARNING = getEntry(s, 67);
        }
        if(!getEntry(s, 68).equals(""))
        {
            OK_BUTTON = getEntry(s, 68);
        }
        if(!getEntry(s, 69).equals(""))
        {
            MATE_IN = getEntry(s, 69);
        }
        if(!getEntry(s, 70).equals(""))
        {
            NO_MATE = getEntry(s, 70);
        }
        if(!getEntry(s, 71).equals(""))
        {
            NO_MORE_MATE = getEntry(s, 71);
        }
        if(!getEntry(s, 72).equals(""))
        {
            ILLEGAL_OP = getEntry(s, 72);
        }
        if(!getEntry(s, 73).equals(""))
        {
            OP_ERROR = getEntry(s, 73);
        }
        if(!getEntry(s, 74).equals(""))
        {
            READ_ERROR = getEntry(s, 74);
        }
        if(!getEntry(s, 75).equals(""))
        {
            CON_ERROR = getEntry(s, 75);
        }
        if(!getEntry(s, 76).equals(""))
        {
            CON_CLOSED = getEntry(s, 76);
        }
        if(!getEntry(s, 77).equals(""))
        {
            CON_OPENED = getEntry(s, 77);
        }
        if(!getEntry(s, 78).equals(""))
        {
            OK_DOT = getEntry(s, 78);
        }
        if(!getEntry(s, 79).equals(""))
        {
            ENTER_PWD = getEntry(s, 79);
        }
        if(!getEntry(s, 80).equals(""))
        {
            SERVER_STARTED = getEntry(s, 80);
        }
        if(!getEntry(s, 81).equals(""))
        {
            SERVER_STOPPED = getEntry(s, 81);
        }
    }

}
