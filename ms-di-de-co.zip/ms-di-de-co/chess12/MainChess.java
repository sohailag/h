/*
      <APPLET CODEBASE="." CODE="Chess.class" WIDTH=438 HEIGHT=332>

      <PARAM NAME="IMGPATH" VALUE="./">

        ALT="Applets are ignored"
        Applets are unknown

      </APPLET>
*/

class MainChess 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
